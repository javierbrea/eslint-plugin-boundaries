import { chromium } from "playwright-core";
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
const dir = path.resolve("bench-out");
const server = http.createServer((req, res) => {
  const u = req.url.split("?")[0];
  if (u === "/" ) { res.setHeader("content-type", "text/html"); return res.end('<!doctype html><html><body style="margin:0"><div id="root" style="width:1280px;height:800px"></div></body></html>'); }
  const f = path.join(dir, path.basename(u));
  if (!fs.existsSync(f)) { res.statusCode = 404; return res.end(); }
  res.setHeader("content-type", "text/javascript"); fs.createReadStream(f).pipe(res);
}).listen(0, "127.0.0.1");
await new Promise((r) => server.once("listening", r));
const base = `http://127.0.0.1:${server.address().port}`;
const browser = await chromium.launch({ args: ["--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
console.log("chromium", browser.version());
const SIZES = process.env.TINY ? { tiny: { n: 40, g: 8, m: 150 } } : { small: { n: 120, g: 12, m: 600 }, big: { n: 1000, g: 12, m: 5000 } };
const only = process.argv[2]; const FWD = Number(process.argv[3] || 0); const pick = process.argv[4];
const CASES = [
  ["cy", ["cy.js"], { layout: "dagre" }], ["cy", ["cy.js"], { layout: "dagre", webgl: true }], ["cy", ["cy.js"], { layout: "fcose" }], ["cy", ["cy.js"], { layout: "fcose-norandom" }], ["cy", ["cy.js"], { layout: "cose" }], ["cy", ["cy-elk.js", "cy.js"], { layout: "elk" }],
  ["rf", ["rf.js"], { layout: "elk" }], ["rf", ["rf.js"], { layout: "elk-worker" }], ["rf", ["rf.js"], { layout: "dagre" }], ["rf", ["rf.js"], { layout: "elk-worker", visibleOnly: true }],
  ["sg", ["sg.js"], { layout: "fa2" }], ["sg", ["sg.js"], { layout: "dagre" }],
];
const med = (a) => a.slice().sort((x, y) => x - y)[Math.floor(a.length / 2)];
for (const [sizeName, size] of Object.entries(SIZES)) for (const [lib, scripts, opts] of CASES) {
  if (only && !only.split(",").includes(lib)) continue; if (pick && !pick.split(",").includes(opts.layout + (opts.webgl ? "+webgl" : "") + (opts.visibleOnly ? "+vis" : ""))) continue;
  const runs = []; let err, extra;
  const reps = sizeName === "small" ? 3 : 2;
  for (let i = 0; i < reps && !err; i++) {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
    page.on("console", (m) => { if (/error|warn/.test(m.type()) && process.env.LOG) console.log("  console:", m.text().slice(0, 200)); }); page.on("pageerror", (e) => { err = String(e).slice(0, 200); });
    try {
      await page.goto(base + "/");
      for (const s of scripts) await page.addScriptTag({ url: "/" + s });
      const r = await Promise.race([page.evaluate((o) => window.bench(o), { ...size, ...opts, fwd: FWD }), new Promise((_, rej) => setTimeout(() => rej(new Error("timeout 240s")), 240000))]);
      runs.push(r); extra = r.dom || r.info;
    } catch (e) { err = String(e.message).slice(0, 300); }
    await page.close();
  }
  const f = (k) => runs.length ? Math.round(med(runs.map((r) => r[k]))) : "-";
  console.log(JSON.stringify({ fwd: FWD, size: sizeName, lib, ...opts, layoutMs: f("layout"), renderMs: f("render"), totalMs: f("total"), deterministic: runs.map((r) => r.deterministic).join(","), samePosAcrossPages: new Set(runs.map((r) => r.h)).size === 1, extra, err }));
}
await browser.close(); server.close();
