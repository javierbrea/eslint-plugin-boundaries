import { createRoot } from "react-dom/client";
import { flushSync } from "react-dom";
import { ReactFlow, MarkerType } from "@xyflow/react";
import css from "@xyflow/react/dist/style.css";
import dagre from "@dagrejs/dagre";
import ELKBundled from "elkjs/lib/elk.bundled.js";
import ELKApi from "elkjs/lib/elk-api.js";
import { gen, raf2, hash } from "./gen.js";
const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
const W = 120, H = 36;
async function elkLayout(d, worker) {
  const elk = worker ? new ELKApi({ workerUrl: "/elk-worker.min.js" }) : new ELKBundled();
  const res = await elk.layout({
    id: "root", layoutOptions: { "elk.algorithm": "layered", "elk.direction": "DOWN", "elk.hierarchyHandling": "INCLUDE_CHILDREN" },
    children: d.groups.map((x) => ({ id: x.id, layoutOptions: { "elk.padding": "[top=30,left=14,bottom=14,right=14]" }, children: d.nodes.filter((nd) => nd.parent === x.id).map((nd) => ({ id: nd.id, width: W, height: H })) })),
    edges: d.edges.map((e) => ({ id: e.id, sources: [e.s], targets: [e.t] })),
  });
  if (worker) elk.terminateWorker();
  const out = new Map();
  for (const grp of res.children) { out.set(grp.id, { x: grp.x, y: grp.y, w: grp.width, h: grp.height }); for (const c of grp.children) out.set(c.id, { x: c.x, y: c.y, w: W, h: H }); }
  return out;
}
function dagreLayout(d) {
  const G = new dagre.graphlib.Graph({ compound: true }); G.setGraph({ rankdir: "TB", nodesep: 26, ranksep: 60 }); G.setDefaultEdgeLabel(() => ({}));
  for (const x of d.groups) G.setNode(x.id, {});
  for (const x of d.nodes) { G.setNode(x.id, { width: W, height: H }); G.setParent(x.id, x.parent); }
  for (const e of d.edges) G.setEdge(e.s, e.t);
  dagre.layout(G);
  const out = new Map();
  for (const x of d.groups) { const p = G.node(x.id); out.set(x.id, { x: p.x - p.width / 2, y: p.y - p.height / 2, w: p.width, h: p.height }); }
  for (const x of d.nodes) { const p = G.node(x.id), pp = out.get(x.parent); out.set(x.id, { x: p.x - W / 2 - pp.x, y: p.y - H / 2 - pp.y, w: W, h: H }); }
  return out;
}
window.bench = async ({ fwd, n, g, m, layout, visibleOnly }) => {
  const d = gen({ n, g, m, fwd });
  const run = async (measureRender) => {
    const t1 = performance.now();
    const pos = layout === "dagre" ? dagreLayout(d) : await elkLayout(d, layout === "elk-worker");
    const t2 = performance.now();
    let render = 0;
    if (measureRender) {
      const nodes = [
        ...d.groups.map((x) => { const p = pos.get(x.id); return { id: x.id, type: "group", position: { x: p.x, y: p.y }, width: p.w, height: p.h, data: { label: x.label } }; }),
        ...d.nodes.map((x) => { const p = pos.get(x.id); return { id: x.id, parentId: x.parent, position: { x: p.x, y: p.y }, width: W, height: H, data: { label: x.label } }; }),
      ];
      const edges = d.edges.map((e) => ({ id: e.id, source: e.s, target: e.t, label: String(e.w), markerEnd: { type: MarkerType.ArrowClosed }, style: { strokeWidth: 1 + e.w / 8, stroke: e.bad ? "#d40" : e.mut ? "#e80" : "#088", strokeDasharray: e.bad ? "6 4" : undefined } }));
      const el = document.getElementById("root"); el.innerHTML = "";
      const root = createRoot(el);
      root.render(<ReactFlow nodes={nodes} edges={edges} fitView minZoom={0.02} onlyRenderVisibleElements={!!visibleOnly} />);
      const want = visibleOnly ? 1 : d.edges.length;
      const t = performance.now();
      while (document.querySelectorAll(".react-flow__edge").length < want && performance.now() - t < 120000) await raf2();
      await raf2();
      render = performance.now() - t2;
      window.__dom = { nodes: document.querySelectorAll(".react-flow__node").length, edges: document.querySelectorAll(".react-flow__edge").length, all: el.querySelectorAll("*").length };
      root.unmount();
    }
    return { layout: t2 - t1, render, total: performance.now() - t1, h: hash([...pos.values()].flatMap((p) => [p.x, p.y])) };
  };
  const a = await run(true), b = await run(false);
  return { ...a, deterministic: a.h === b.h, dom: window.__dom };
};
