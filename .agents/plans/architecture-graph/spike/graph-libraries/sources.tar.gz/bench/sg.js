import Graph from "graphology";
import Sigma, { DEFAULT_STYLES } from "sigma";
import { extremityArrow, layerDashed, layerPlain, layerFill, pathLine, sdfCircle } from "sigma/rendering";
import fa2 from "graphology-layout-forceatlas2";
import dagre from "@dagrejs/dagre";
import { gen, raf2, hash } from "./gen.js";
window.bench = async ({ fwd, n, g, m, layout }) => {
  const d = gen({ n, g, m, fwd });
  const run = async (measureRender) => {
    const el = document.getElementById("root"); el.innerHTML = "";
    const t0 = performance.now();
    const graph = new Graph({ type: "directed" });
    d.nodes.forEach((x, i) => { const a = (2 * Math.PI * i) / n; graph.addNode(x.id, { label: x.label, x: Math.cos(a) * 100, y: Math.sin(a) * 100, size: 6, color: "#0a7" }); });
    for (const e of d.edges) graph.addEdgeWithKey(e.id, e.s, e.t, { size: 0.5 + e.w / 12, color: e.bad ? "#d40" : e.mut ? "#e80" : "#088", dashSize: e.bad ? 6 : 0, head: "arrow", label: String(e.w), weight: e.w });
    const t1 = performance.now();
    if (layout === "fa2") fa2.assign(graph, { iterations: 300, settings: { ...fa2.inferSettings(graph), adjustSizes: true } });
    else {
      const G = new dagre.graphlib.Graph(); G.setGraph({ rankdir: "TB" }); G.setDefaultEdgeLabel(() => ({}));
      graph.forEachNode((id) => G.setNode(id, { width: 60, height: 20 }));
      graph.forEachEdge((_e, _a, s, t) => G.setEdge(s, t));
      dagre.layout(G);
      graph.forEachNode((id) => { const p = G.node(id); graph.mergeNodeAttributes(id, { x: p.x, y: -p.y }); });
    }
    const t2 = performance.now();
    if (measureRender) {
      const r = new Sigma(graph, el, {
        primitives: { nodes: { shapes: [sdfCircle()], layers: [layerFill()] }, edges: { variables: { dashSize: { type: "number", default: 0 } }, paths: [pathLine()], extremities: [extremityArrow()], layers: [layerPlain(), layerDashed({ dashSize: { attribute: "dashSize" }, gapSize: { value: 4 }, dashColor: { value: "#ffffff" } })] } },
        styles: { nodes: [DEFAULT_STYLES.nodes], edges: [DEFAULT_STYLES.edges, { head: { attribute: "head" } }] },
        settings: { renderEdgeLabels: true, itemSizesReference: "screen" },
      });
      await new Promise((res) => r.once("afterRender", res)); await raf2();
      window.__info = { canvases: el.querySelectorAll("canvas").length, dom: el.querySelectorAll("*").length };
      r.kill();
    }
    const t3 = performance.now();
    const pos = []; graph.forEachNode((_id, a) => pos.push(a.x, a.y));
    return { init: t1 - t0, layout: t2 - t1, render: t3 - t2, total: t3 - t0, h: hash(pos) };
  };
  const a = await run(true), b = await run(false);
  return { ...a, deterministic: a.h === b.h, info: window.__info };
};
