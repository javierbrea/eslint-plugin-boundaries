import elk from "cytoscape-elk";
globalThis.__cyElk = elk;
