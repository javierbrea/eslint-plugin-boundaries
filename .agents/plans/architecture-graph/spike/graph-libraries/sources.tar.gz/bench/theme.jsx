import { createRoot } from "react-dom/client";
import { ReactFlow } from "@xyflow/react";
import css from "@xyflow/react/dist/style.css";
const st = document.createElement("style"); st.textContent = css + ":root{--jsb-ok:rgb(0,128,128)} [data-theme=dark]{--jsb-ok:rgb(90,200,200)}"; document.head.appendChild(st);
window.bench = async () => {
  const nodes = [{ id: "a", position: { x: 0, y: 0 }, data: { label: "a" } }, { id: "b", position: { x: 200, y: 150 }, data: { label: "b" } }];
  const edges = [{ id: "e", source: "a", target: "b", label: "12", style: { stroke: "var(--jsb-ok)", strokeWidth: 4, strokeDasharray: "6 4" } }];
  createRoot(document.getElementById("root")).render(<ReactFlow nodes={nodes} edges={edges} fitView />);
  await new Promise((r) => setTimeout(r, 1500));
  const p = document.querySelector(".react-flow__edge-path"); const cs = () => getComputedStyle(p);
  const light = cs().stroke; document.documentElement.dataset.theme = "dark"; const dark = cs().stroke;
  const n = document.querySelector(".react-flow__node"), e = document.querySelector(".react-flow__edge");
  return { light, dark, dash: cs().strokeDasharray, width: cs().strokeWidth, nodeAttrs: [...n.attributes].filter((a) => /role|aria|tabindex/.test(a.name)).map((a) => a.name + "=" + a.value), edgeAttrs: [...e.attributes].filter((a) => /role|aria|tabindex/.test(a.name)).map((a) => a.name + "=" + a.value), attribution: document.querySelector(".react-flow__attribution")?.textContent, live: document.querySelectorAll("[aria-live]").length };
};
