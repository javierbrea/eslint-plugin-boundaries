import cytoscape from "cytoscape";
import dagre from "cytoscape-dagre";
import fcose from "cytoscape-fcose";
import { gen, raf2, hash } from "./gen.js";
cytoscape.use(dagre); cytoscape.use(fcose);
if (globalThis.__cyElk) cytoscape.use(globalThis.__cyElk);
const LAYOUTS = {
  dagre: { name: "dagre", rankDir: "TB", nodeSep: 26, rankSep: 60 },
  fcose: { name: "fcose", animate: false, quality: "default" },
  "fcose-norandom": { name: "fcose", animate: false, quality: "proof", randomize: false },
  cose: { name: "cose", animate: false },
  elk: { name: "elk", elk: { algorithm: "layered", "elk.direction": "DOWN", "elk.hierarchyHandling": "INCLUDE_CHILDREN" } },
};
window.bench = async ({ fwd, n, g, m, layout, webgl }) => {
  const d = gen({ n, g, m, fwd });
  const elements = [
    ...d.groups.map((x) => ({ data: { id: x.id, label: x.label }, classes: "parent" })),
    ...d.nodes.map((x) => ({ data: { id: x.id, label: x.label, parent: x.parent } })),
    ...d.edges.map((e) => ({ data: { id: e.id, source: e.s, target: e.t, w: 1 + e.w / 8, label: String(e.w) }, classes: e.bad ? "bad" : e.mut ? "mut" : "" })),
  ];
  const style = [
    { selector: "node", style: { label: "data(label)", width: 28, height: 28, "background-color": "#0a7", "font-size": 11 } },
    { selector: "node.parent", style: { "background-opacity": 0.06, "border-width": 1, shape: "round-rectangle", padding: 14, "text-valign": "top" } },
    { selector: "edge", style: { width: "data(w)", "line-color": "#088", "target-arrow-color": "#088", "target-arrow-shape": "triangle", "curve-style": "bezier", opacity: 0.55 } },
    { selector: "edge.mut", style: { "line-color": "#e80", "target-arrow-color": "#e80" } },
    { selector: "edge.bad", style: { "line-color": "#d40", "target-arrow-color": "#d40", "line-style": "dashed" } },
  ];
  const run = async (measureRender) => {
    document.getElementById("root").innerHTML = "";
    const t0 = performance.now();
    const cy = cytoscape({ container: document.getElementById("root"), elements, style, layout: { name: "preset" }, renderer: webgl ? { name: "canvas", webgl: true } : undefined });
    const t1 = performance.now();
    const l = cy.layout(LAYOUTS[layout]);
    const stop = new Promise((r) => l.one("layoutstop", r));
    l.run(); await stop;
    const t2 = performance.now();
    cy.fit();
    if (measureRender) { await Promise.race([new Promise((r) => cy.one("render", r)), new Promise((r) => setTimeout(() => { window.__noRender = true; r(); }, 15000))]); await raf2(); }
    const t3 = performance.now();
    const pos = cy.nodes(":childless").map((x) => [x.position("x"), x.position("y")]).flat();
    cy.destroy();
    return { init: t1 - t0, layout: t2 - t1, render: t3 - t2, total: t3 - t0, h: hash(pos) };
  };
  const a = await run(true), b = await run(false);
  return { ...a, deterministic: a.h === b.h, info: { noRenderEvent: !!window.__noRender, canvases: document.querySelectorAll("canvas").length } };
};
