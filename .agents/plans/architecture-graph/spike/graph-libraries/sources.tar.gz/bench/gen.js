export function gen({ n, g, m, seed = 42, fwd = 0 }) {
  let a = seed >>> 0;
  const rnd = () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const groups = Array.from({ length: g }, (_, i) => ({ id: "g" + i, label: "type-" + i }));
  const nodes = Array.from({ length: n }, (_, i) => ({ id: "n" + i, label: "element-" + i, parent: "g" + (fwd ? Math.floor((i * g) / n) : i % g) }));
  const seen = new Set(); const edges = [];
  while (edges.length < m) {
    let s = Math.floor(rnd() * n), t = Math.floor(rnd() * n);
    if (fwd && s > t && rnd() < fwd) [s, t] = [t, s];
    if (s === t || seen.has(s + ">" + t)) continue;
    seen.add(s + ">" + t);
    edges.push({ id: "e" + edges.length, s: "n" + s, t: "n" + t, w: 1 + Math.floor(rnd() * 40), bad: rnd() < 0.1 });
  }
  for (const e of edges) e.mut = seen.has(e.t.slice(1) + ">" + e.s.slice(1));
  return { groups, nodes, edges };
}
export const raf2 = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
export const hash = (arr) => { let h = 0; for (const v of arr) h = (Math.imul(h, 31) + Math.round(v * 10)) | 0; return h; };
