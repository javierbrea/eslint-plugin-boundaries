import cytoscape from "cytoscape";
const cy = cytoscape({ headless: true, styleEnabled: true, elements: [{ data: { id: "a" } }], style: [{ selector: "node", style: { "background-color": "var(--jsb-accent)" } }] });
console.log("computed background-color with var():", cy.$("#a").style("background-color"));
cy.style().fromJson([{ selector: "node", style: { "background-color": "#ff0000" } }]).update();
console.log("after cy.style().fromJson().update():", cy.$("#a").style("background-color"));
