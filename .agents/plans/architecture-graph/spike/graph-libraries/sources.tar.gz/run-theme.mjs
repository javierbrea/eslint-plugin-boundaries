import { chromium } from "playwright-core";
const b = await chromium.launch(); const p = await b.newPage();
await p.setContent('<div id="root" style="width:800px;height:600px"></div>'); await p.addScriptTag({ path: "bench-out/theme.js" });
console.log(JSON.stringify(await p.evaluate(() => window.bench()))); await b.close();
