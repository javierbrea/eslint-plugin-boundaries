import React from "react"; import { renderToString } from "react-dom/server"; import { ReactFlow } from "@xyflow/react";
const nodes=[{id:"g",type:"group",position:{x:0,y:0},width:300,height:200,data:{}},{id:"a",parentId:"g",position:{x:10,y:10},width:100,height:30,data:{label:"a"}},{id:"b",position:{x:400,y:10},width:100,height:30,data:{label:"b"}}];
const html=renderToString(React.createElement(ReactFlow,{nodes,edges:[{id:"e",source:"a",target:"b"}],width:800,height:600,fitView:true}));
console.log("React Flow renderToString ok, bytes", html.length, "nodes in html:", (html.match(/react-flow__node /g)||[]).length, "edges:", (html.match(/react-flow__edge /g)||[]).length);
