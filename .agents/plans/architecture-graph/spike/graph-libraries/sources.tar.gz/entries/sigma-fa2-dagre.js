import Sigma from "sigma"; import Graph from "graphology"; import fa2 from "graphology-layout-forceatlas2"; import dagre from "@dagrejs/dagre"; globalThis.x=[Sigma, Graph, fa2, dagre];
