import dagre from "@dagrejs/dagre"; globalThis.x=[dagre];
