import cytoscape from "cytoscape"; import dagre from "cytoscape-dagre"; import fcose from "cytoscape-fcose"; cytoscape.use(dagre); cytoscape.use(fcose); globalThis.x=[cytoscape];
