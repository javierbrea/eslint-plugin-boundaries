import ELK from "elkjs/lib/elk.bundled.js"; globalThis.x=[ELK];
