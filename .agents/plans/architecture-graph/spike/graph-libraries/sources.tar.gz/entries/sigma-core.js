import Sigma from "sigma"; import Graph from "graphology"; globalThis.x=[Sigma, Graph];
