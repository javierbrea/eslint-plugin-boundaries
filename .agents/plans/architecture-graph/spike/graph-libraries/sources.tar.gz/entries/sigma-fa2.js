import Sigma from "sigma"; import Graph from "graphology"; import fa2 from "graphology-layout-forceatlas2"; globalThis.x=[Sigma, Graph, fa2];
