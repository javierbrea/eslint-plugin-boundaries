import cytoscape from "cytoscape"; globalThis.x=[cytoscape];
