import { ReactFlow, Handle, Position, BaseEdge, getBezierPath } from "@xyflow/react"; globalThis.x=[ReactFlow, Handle, Position, BaseEdge, getBezierPath];
