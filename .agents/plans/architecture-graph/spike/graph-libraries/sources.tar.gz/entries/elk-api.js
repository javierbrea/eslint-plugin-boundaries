import ELK from "elkjs/lib/elk-api.js"; globalThis.x=[ELK];
