import cytoscape from "cytoscape"; import dagre from "cytoscape-dagre"; import ec from "cytoscape-expand-collapse"; cytoscape.use(dagre); cytoscape.use(ec); globalThis.x=[cytoscape];
