import cytoscape from "cytoscape"; import elk from "cytoscape-elk"; cytoscape.use(elk); globalThis.x=[cytoscape];
