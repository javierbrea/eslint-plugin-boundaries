// Debug: where does the page stop?
import { createRequire } from "node:module";
const requireScratch = createRequire(new URL("../graph-lib-research/node_modules/placeholder.js", import.meta.url));
const { chromium } = requireScratch("playwright-core");
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage();
page.on("console", (m) => console.log("[page]", m.text()));
page.on("pageerror", (e) => console.log("[pageerror]", e.message));
await page.goto(process.argv[2]);
const r = await page.evaluate(async () => {
  const log = [];
  const raf = await Promise.race([new Promise((r) => requestAnimationFrame(() => r("raf ok"))), new Promise((r) => setTimeout(() => r("raf timeout"), 3000))]);
  log.push(raf);
  const w = new Worker("/worker.js", { type: "module" });
  const first = await Promise.race([
    new Promise((r) => { w.onmessage = (e) => r("msg " + JSON.stringify(e.data).slice(0, 200)); w.onerror = (e) => r("error " + e.message + " " + e.filename + ":" + e.lineno); }),
    new Promise((r) => setTimeout(() => r("worker timeout"), 5000)),
  ]);
  log.push(first);
  const sketch = await (await fetch("/sketch?size=real")).json();
  const second = await Promise.race([
    new Promise((r) => { const got = []; w.onmessage = (e) => { got.push(e.data.kind); if (e.data.kind === "timings") r("got " + got + " " + JSON.stringify(e.data.timings)); }; w.onerror = (e) => r("error " + e.message + " " + e.lineno); w.postMessage({ cmd: "evaluate", mode: "evaluation", sketch }); }),
    new Promise((r) => setTimeout(() => r("evaluate timeout"), 20000)),
  ]);
  log.push(second);
  return log;
});
console.log(r);
await browser.close();
