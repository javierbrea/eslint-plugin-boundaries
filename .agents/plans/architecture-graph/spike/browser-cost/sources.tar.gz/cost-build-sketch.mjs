// Reads a real project into the `Sketch` of the playground: config through the ESLint API, imports through TypeScript (as spike/read-project.mjs does).
// Usage: node cost-build-sketch.mjs <projectDir> <outDir>
import fs from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";

const projectDir = path.resolve(process.argv[2]);
const outDir = path.resolve(process.argv[3]);
const requireFromProject = createRequire(path.join(projectDir, "package.json"));
const { ESLint } = requireFromProject("eslint");
const ts = requireFromProject("typescript");

const walk = (dir) =>
  fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    if (e.isDirectory()) return walk(path.join(dir, e.name));
    return /\.(ts|tsx)$/.test(e.name) ? [path.join(dir, e.name)] : [];
  });
const absFiles = walk(path.join(projectDir, "src"));
const rel = (abs) => path.relative(projectDir, abs).split(path.sep).join("/");
const fileSet = new Set(absFiles.map(rel));

// 1. Config
const eslint = new ESLint({ cwd: projectDir });
const configs = new Map();
for (const file of absFiles) {
  const c = await eslint.calculateConfigForFile(file);
  if (!c) continue;
  const boundaries = {
    settings: Object.fromEntries(
      Object.entries(c.settings ?? {}).filter(([k]) => k.startsWith("boundaries/"))
    ),
    rules: Object.fromEntries(
      Object.entries(c.rules ?? {}).filter(([k]) => k.startsWith("boundaries/"))
    ),
  };
  const key = JSON.stringify(boundaries);
  if (!configs.has(key)) configs.set(key, { boundaries, files: 0 });
  configs.get(key).files++;
}
const main = [...configs.values()].sort((a, b) => b.files - a.files)[0].boundaries;
console.error(
  `files ${absFiles.length}; distinct boundaries configs ${configs.size} (${[...configs.values()].map((c) => c.files).join(", ")})`
);
console.error("settings keys:", Object.keys(main.settings).join(", "));
console.error("root-path:", JSON.stringify(main.settings["boundaries/root-path"]));
console.error(
  "rules:",
  Object.entries(main.rules)
    .map(([k, v]) => `${k}=${Array.isArray(v) ? v[0] : v}`)
    .join(" ")
);

// 2. Dependencies
const tsconfigPath = ts.findConfigFile(projectDir, ts.sys.fileExists, "tsconfig.json");
const parsedTs = ts.parseJsonConfigFileContent(
  ts.readConfigFile(tsconfigPath, ts.sys.readFile).config,
  ts.sys,
  path.dirname(tsconfigPath)
);
const dependencies = [];
const stats = { insideButNotInTree: 0, external: 0, node: 0 };
for (const file of absFiles) {
  const sf = ts.createSourceFile(file, fs.readFileSync(file, "utf8"), ts.ScriptTarget.Latest, true);
  const add = (source, importKind, syntax, specifiers) => {
    const r = ts.resolveModuleName(source, file, parsedTs.options, ts.sys).resolvedModule;
    const inside =
      r && !r.isExternalLibraryImport && !path.relative(projectDir, r.resolvedFileName).startsWith("..");
    let target;
    if (inside && fileSet.has(rel(r.resolvedFileName))) {
      target = { kind: "node", path: rel(r.resolvedFileName) };
      stats.node++;
    } else {
      if (inside) stats.insideButNotInTree++;
      stats.external++;
      target = { kind: "external", name: source };
    }
    dependencies.push({ from: rel(file), target, syntax, importKind, specifiers });
  };
  const visit = (node) => {
    if (ts.isImportDeclaration(node) && ts.isStringLiteral(node.moduleSpecifier)) {
      const clause = node.importClause;
      const specifiers = [];
      if (clause?.name) specifiers.push({ kind: "default", name: clause.name.text });
      if (clause?.namedBindings) {
        if (ts.isNamespaceImport(clause.namedBindings)) {
          specifiers.push({ kind: "namespace", name: clause.namedBindings.name.text });
        } else {
          for (const e of clause.namedBindings.elements) {
            specifiers.push(
              e.propertyName
                ? { kind: "named", name: e.propertyName.text, alias: e.name.text }
                : { kind: "named", name: e.name.text }
            );
          }
        }
      }
      add(node.moduleSpecifier.text, clause?.isTypeOnly ? "type" : "value", "import", specifiers);
    } else if (
      ts.isExportDeclaration(node) &&
      node.moduleSpecifier &&
      ts.isStringLiteral(node.moduleSpecifier)
    ) {
      const specifiers = [];
      if (!node.exportClause) specifiers.push({ kind: "namespace", name: "*" });
      else if (ts.isNamespaceExport(node.exportClause)) {
        specifiers.push({ kind: "namespace", name: node.exportClause.name.text });
      } else {
        for (const e of node.exportClause.elements) {
          specifiers.push(
            e.propertyName
              ? { kind: "named", name: e.propertyName.text, alias: e.name.text }
              : { kind: "named", name: e.name.text }
          );
        }
      }
      add(node.moduleSpecifier.text, node.isTypeOnly ? "type" : "value", "export-from", specifiers);
    } else if (
      ts.isCallExpression(node) &&
      node.arguments.length === 1 &&
      ts.isStringLiteral(node.arguments[0])
    ) {
      if (node.expression.kind === ts.SyntaxKind.ImportKeyword) {
        add(node.arguments[0].text, "value", "dynamic-import", []);
      } else if (ts.isIdentifier(node.expression) && node.expression.text === "require") {
        add(node.arguments[0].text, "value", "require", []);
      }
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);
}
console.error(`dependencies ${dependencies.length}`, JSON.stringify(stats));

const sketch = {
  config: JSON.stringify(main, null, 2),
  tree: [...fileSet].sort().map((p) => ({ path: p, kind: "file" })),
  dependencies,
};
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, "sketch-real.json"), JSON.stringify(sketch));
console.error(
  `written sketch-real.json: ${sketch.tree.length} files, ${sketch.dependencies.length} dependencies, config ${sketch.config.length} chars`
);
