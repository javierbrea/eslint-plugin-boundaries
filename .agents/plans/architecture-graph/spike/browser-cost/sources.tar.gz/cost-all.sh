#!/bin/zsh
# The whole measurement, one size after another. Usage: zsh cost-all.sh
cd "$(dirname "$0")"
export PATH=~/.nvm/versions/node/v24.22.3/bin:$PATH
export TMPDIR="$PWD/tmp"
mkdir -p "$TMPDIR"
sysctl vm.swapusage
TAG=main node cost-run.mjs real,1,2,5 5 5
TAG=main node cost-run.mjs 10 3 3
TAG=main node cost-run.mjs 20 2 2
sysctl vm.swapusage
TAG=main node cost-run.mjs 40 1 1
sysctl vm.swapusage
