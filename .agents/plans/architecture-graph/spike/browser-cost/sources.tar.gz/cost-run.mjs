// Bundles the real built worker of the playground behind the timing wrapper, serves it with the sketches and drives headless Chromium.
// Usage: node cost-run.mjs <sizes, such as real,1,2,5,10> [freshWorkers] [warmRuns]
import fs from "node:fs";
import http from "node:http";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = "<repository>";
const requireScratch = createRequire(
  path.join(here, "../graph-lib-research/node_modules/placeholder.js")
);
const esbuild = requireScratch("esbuild");
const { chromium } = requireScratch("playwright-core");

const sizes = (process.argv[2] ?? "real,1,2,5,10").split(",");
const freshWorkers = Number(process.argv[3] ?? 5);
const warmRuns = Number(process.argv[4] ?? 5);

// 1. The worker: the wrapper plus dist/evaluation.worker.js, with the bare imports of the dist file resolved from packages/playground, as the bundler of a host does
const realWorker = path.join(repo, "packages/playground/dist/evaluation.worker.js");
const wrapper = fs
  .readFileSync(path.join(here, "cost-worker-wrapper.js"), "utf8")
  .replace("REAL_WORKER_PATH", realWorker);
const bundle = await esbuild.build({
  stdin: { contents: wrapper, resolveDir: here, sourcefile: "cost-worker-wrapper.js" },
  bundle: true,
  // The package says `sideEffects: false`, which would drop the import of the worker script, whose only effect is to serve
  plugins: [
    {
      name: "keep-worker",
      setup(build) {
        build.onResolve({ filter: /evaluation\.worker\.js$/ }, (args) => ({ path: args.path, sideEffects: true }));
      },
    },
  ],
  format: "esm",
  platform: "browser",
  write: false,
  minify: process.env.MINIFY === "1",
  define: { "process.env.NODE_ENV": '"production"' },
});
const workerCode = bundle.outputFiles[0].text;
console.error(`worker bundle: ${(workerCode.length / 1024).toFixed(0)} kB (esbuild ${esbuild.version})`);

// 2. The sketches: the real one, and N copies under c1/ … cN/ with the patterns of the config prefixed by one folder
const real = JSON.parse(fs.readFileSync(path.join(here, "data/sketch-real.json"), "utf8"));
function scale(copies) {
  const config = JSON.parse(real.config);
  config.settings["boundaries/elements"] = config.settings["boundaries/elements"].map(
    (element) => ({
      ...element,
      pattern: `*/${element.pattern}`,
      ...(element.capture ? { capture: ["copy", ...element.capture] } : {}),
    })
  );
  config.settings["boundaries/files"] = config.settings["boundaries/files"].map((file) => ({
    ...file,
    pattern: `*/${file.pattern}`,
  }));
  const tree = [];
  const dependencies = [];
  for (let copy = 1; copy <= copies; copy++) {
    const prefix = `c${copy}/`;
    for (const node of real.tree) tree.push({ ...node, path: prefix + node.path });
    for (const dependency of real.dependencies) {
      dependencies.push({
        ...dependency,
        from: prefix + dependency.from,
        target:
          dependency.target.kind === "node"
            ? { kind: "node", path: prefix + dependency.target.path }
            : dependency.target,
      });
    }
  }
  return { config: JSON.stringify(config, null, 2), tree, dependencies };
}

const server = http.createServer((request, response) => {
  const url = new URL(request.url, "http://localhost");
  if (url.pathname === "/") {
    response.setHeader("content-type", "text/html");
    response.end('<!doctype html><meta charset="utf-8"><title>cost</title><script src="/page.js"></script>');
  } else if (url.pathname === "/page.js") {
    response.setHeader("content-type", "text/javascript");
    response.end(fs.readFileSync(path.join(here, "cost-page.js")));
  } else if (url.pathname === "/worker.js") {
    response.setHeader("content-type", "text/javascript");
    response.end(workerCode);
  } else if (url.pathname === "/sketch") {
    const size = url.searchParams.get("size");
    response.setHeader("content-type", "application/json");
    response.end(JSON.stringify(size === "real" ? real : scale(Number(size))));
  } else {
    response.statusCode = 404;
    response.end();
  }
});
await new Promise((resolve) => server.listen(Number(process.env.PORT ?? 0), "127.0.0.1", resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
if (process.env.SERVE === "1") {
  console.log(origin);
  await new Promise(() => {});
}

const browser = await chromium.launch({ headless: true });
console.error(`chromium ${browser.version()} headless; playwright-core ${requireScratch("playwright-core/package.json").version}; node ${process.version}`);
fs.mkdirSync(path.join(here, "results"), { recursive: true });
const tag = process.env.TAG ?? "run";
try {
  for (const size of sizes) {
    const page = await browser.newPage();
    page.on("console", (message) => console.error("[page]", message.text()));
    page.on("pageerror", (error) => console.error("[page error]", error.message));
    await page.goto(origin);
    await page.waitForFunction(() => window.cost);
    if (size === sizes[0]) {
      const direct = await page.evaluate(() => window.cost.directTest());
      console.error("direct structured clone test:", JSON.stringify(direct));
      fs.writeFileSync(path.join(here, "results", `${tag}-direct.json`), JSON.stringify(direct, null, 1));
    }
    const started = Date.now();
    const result = await page.evaluate((options) => window.cost.run(options), {
      url: `/sketch?size=${size}`,
      prefix: size === "real" ? "" : "c1/",
      freshWorkers,
      warmRuns,
      echoRuns: Number(process.env.ECHO_RUNS ?? 20),
      cloneRuns: Number(process.env.CLONE_RUNS ?? 20),
      aggregateRuns: Number(process.env.AGGREGATE_RUNS ?? 30),
    });
    result.size = size;
    result.wallSeconds = (Date.now() - started) / 1000;
    result.browser = browser.version();
    fs.writeFileSync(path.join(here, "results", `${tag}-${size}.json`), JSON.stringify(result, null, 1));
    console.error(
      `size ${size}: ${result.files} files, ${result.dependencies} deps, ${result.wallSeconds.toFixed(1)} s; verdicts ${JSON.stringify(result.verdicts)}; problems ${result.problems}`
    );
    await page.close();
  }
} finally {
  await browser.close();
  server.close();
}
