// Cross-check: the same built worker script, run in Node.js with a stub of `self`, for the real sketch.
import fs from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
const here = path.dirname(fileURLToPath(import.meta.url));
const requireScratch = createRequire(path.join(here, "../graph-lib-research/node_modules/placeholder.js"));
const esbuild = requireScratch("esbuild");
const out = path.join(here, "tmp/node-worker.mjs");
await esbuild.build({
  entryPoints: ["<repository>/packages/playground/dist/evaluation.worker.js"],
  bundle: true, format: "esm", platform: "browser", outfile: out,
  define: { "process.env.NODE_ENV": '"production"' },
});
let reply;
globalThis.self = { postMessage: (value) => { reply = value; } };
await import(out);
const sketch = JSON.parse(fs.readFileSync(path.join(here, "data/sketch-real.json"), "utf8"));
const times = [];
for (let index = 0; index < 12; index++) {
  const copy = { ...sketch, tree: [...sketch.tree, { path: `src/added-${index}.ts`, kind: "file" }] };
  const start = performance.now();
  self.onmessage({ data: copy });
  times.push(performance.now() - start);
}
console.log("node", process.version, "first", times[0].toFixed(0), "warm median", times.slice(1).sort((a, b) => a - b)[5].toFixed(0), "ms; deps", reply.dependencies.length);
