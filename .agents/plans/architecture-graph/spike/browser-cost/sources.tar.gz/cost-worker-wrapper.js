// Wraps the real built worker script of the playground (dist/evaluation.worker.js) to time it from the outside and to simulate the reply with both forms.
// The import runs first (ES imports are hoisted): the real script sets `self.onmessage` and replies with `self.postMessage`.
import "REAL_WORKER_PATH";

const realHandler = self.onmessage;
const realPost = self.postMessage.bind(self);
const RULE = "boundaries/dependencies";

let mode = "evaluation";
let timings;
let lastReply;
const built = {};

/** The second form of decision 14, from the real Evaluation, sharing the description objects by reference */
function toAnalysis(evaluation, thick) {
  const refs = new Map();
  const refOf = (policy) => {
    if (!policy) return undefined;
    let ref = refs.get(policy);
    if (!ref) {
      ref = {
        index: policy.index,
        path:
          policy.index === null
            ? ["rules", RULE, 1, "default"]
            : ["rules", RULE, 1, "policies", policy.index],
      };
      refs.set(policy, ref);
    }
    return ref;
  };
  const toVerdict = (verdict) => {
    if (verdict.status === "allowed") return { status: "allowed", policy: refOf(verdict.policy) };
    if (verdict.status === "disallowed") {
      return {
        status: "disallowed",
        policy: refOf(verdict.policy),
        message: verdict.message,
        level: verdict.level,
      };
    }
    return { ...verdict };
  };
  const withPath = ({ range: _range, ...rest }, path) => ({ ...rest, path });
  return {
    files: new Map(evaluation.files),
    dependencies: evaluation.dependencies.map((result) => ({
      dependency: thick
        ? {
            from: result.dependency.from,
            target:
              result.dependency.target.kind === "node"
                ? { kind: "file", path: result.dependency.target.path }
                : { kind: "external", name: result.dependency.target.name },
            syntax: result.dependency.syntax,
            importKind: result.dependency.importKind,
            specifiers: result.dependency.specifiers,
            source: result.source,
          }
        : result.dependency,
      ref: result.ref,
      source: result.source,
      description: result.description,
      verdict: toVerdict(result.verdict),
    })),
    diagnostics: evaluation.problems.map(({ range: _range, ...rest }) => rest),
    rulesValid: evaluation.rulesValid,
    notEvaluated: evaluation.notEvaluated,
    policies: evaluation.policies.map((policy) =>
      withPath(policy, refOf(policy).path)
    ),
    elementTypes: evaluation.elementTypes.map((type) =>
      withPath(type, ["settings", "boundaries/elements", type.index])
    ),
    fileCategories: evaluation.fileCategories.map((category) =>
      withPath(category, ["settings", "boundaries/files", category.index])
    ),
    rules: evaluation.rules.map((rule) => withPath(rule, ["rules", rule.name])),
  };
}

function payloadOf(form) {
  if (form === "evaluation") return lastReply;
  if (!built[form]) {
    const start = performance.now();
    built[form] = { evaluation: lastReply, analysis: toAnalysis(lastReply, form === "thick") };
    built[`${form}BuildMs`] = performance.now() - start;
  }
  return built[form];
}

// What the real script calls with its reply
self.postMessage = (reply) => {
  timings.evaluateMs = performance.now() - timings.handlerStart;
  lastReply = reply;
  delete built.thin;
  delete built.thick;
  let payload = reply;
  if (mode === "thin" || mode === "thick") {
    payload = payloadOf(mode);
    timings.buildMs = built[`${mode}BuildMs`];
  }
  if (mode === "none") {
    timings.postMs = 0;
    realPost({ kind: "reply", payload: null });
    return;
  }
  const start = performance.now();
  realPost({ kind: "reply", payload });
  timings.postMs = performance.now() - start;
};

self.onmessage = (event) => {
  const start = performance.now();
  const message = event.data;
  const readMs = performance.now() - start;
  if (message.cmd === "evaluate") {
    mode = message.mode;
    timings = { readMs };
    timings.handlerStart = performance.now();
    realHandler({ data: message.sketch });
    realPost({ kind: "timings", timings });
  } else if (message.cmd === "echo") {
    const payload = payloadOf(message.form);
    const postStart = performance.now();
    realPost({ kind: "reply", payload });
    const postMs = performance.now() - postStart;
    realPost({ kind: "timings", timings: { postMs, buildMs: built[`${message.form}BuildMs`] } });
  } else if (message.cmd === "clone") {
    const payload = payloadOf(message.form);
    const runs = [];
    for (let index = 0; index < message.runs; index++) {
      const cloneStart = performance.now();
      structuredClone(payload);
      runs.push(performance.now() - cloneStart);
    }
    realPost({ kind: "reply", payload: null });
    realPost({ kind: "timings", timings: { runs } });
  } else if (message.cmd === "build") {
    // Time of building the second form alone, each time from scratch
    const runs = [];
    for (let index = 0; index < message.runs; index++) {
      const buildStart = performance.now();
      toAnalysis(lastReply, message.form === "thick");
      runs.push(performance.now() - buildStart);
    }
    realPost({ kind: "reply", payload: null });
    realPost({ kind: "timings", timings: { runs } });
  }
};

realPost({ kind: "ready" });
