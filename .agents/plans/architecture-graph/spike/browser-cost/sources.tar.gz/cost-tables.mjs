// Prints the tables of the report from results/<tag>-<size>.json. Usage: node cost-tables.mjs [tag] [sizes]
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const tag = process.argv[2] ?? "main";
const sizes = (process.argv[3] ?? "real,1,2,5,10,20,40").split(",");
const median = (values) => {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
};
const f = (value, digits = 0) => (value === undefined ? "-" : value.toFixed(digits));
const med = (runs, pick) => median(runs.map(pick));
const max = (runs, pick) => Math.max(...runs.map(pick));
const results = sizes
  .filter((size) => fs.existsSync(path.join(here, "results", `${tag}-${size}.json`)))
  .map((size) => JSON.parse(fs.readFileSync(path.join(here, "results", `${tag}-${size}.json`), "utf8")));
const row = (cells) => console.log(`| ${cells.join(" | ")} |`);
const head = (cells) => {
  row(cells);
  row(cells.map(() => "---"));
};
const label = (r) => [r.size === "real" ? "1x real" : `${r.size}x`, r.files, r.dependencies];

console.log("\n1. Evaluation in the worker (ms, medians; n = runs)\n");
head(["size", "files", "deps", "n first/warm", "evaluate first", "evaluate warm", "files only (warm)", "round trip first", "round trip warm", "page: post sketch", "worker: read sketch", "worker: post reply", "page: read reply", "longest frame (max)", "idle frame", "worker load"]);
for (const r of results) {
  row([
    ...label(r),
    `${r.first.length}/${r.warm.length}`,
    f(med(r.first, (x) => x.worker.evaluateMs)),
    f(med(r.warm, (x) => x.worker.evaluateMs)),
    f(med(r.filesOnly, (x) => x.worker.evaluateMs)),
    f(med(r.first, (x) => x.roundTripMs)),
    f(med(r.warm, (x) => x.roundTripMs)),
    f(med([...r.first, ...r.warm], (x) => x.sendMs), 1),
    f(med([...r.first, ...r.warm], (x) => x.worker.readMs), 1),
    f(med([...r.first, ...r.warm], (x) => x.worker.postMs), 1),
    f(med([...r.first, ...r.warm], (x) => x.replyReadMs), 1),
    f(max([...r.first, ...r.warm], (x) => x.longestFrameMs), 1),
    f(r.idleLongestFrameMs, 1),
    f(median(r.loadMs)),
  ]);
}
console.log("\nranges of evaluate (min-max): first / warm");
for (const r of results) {
  const of = (runs) => `${f(Math.min(...runs.map((x) => x.worker.evaluateMs)))}-${f(max(runs, (x) => x.worker.evaluateMs))}`;
  console.log(`  ${label(r)[0]}: ${of(r.first)} / ${of(r.warm)}; verdicts ${JSON.stringify(r.verdicts)}; problems ${r.problems}`);
}

console.log("\n2a. structuredClone of the reply (ms, median of n)\n");
head(["size", "files", "deps", "n", "page: Evaluation", "page: + thin", "page: + thick", "extra thin", "extra thick", "worker: Evaluation", "worker: + thin", "worker: + thick", "build thin", "build thick"]);
const extra = (a, b) => `+${f(b - a, 1)} (+${f(((b - a) / a) * 100)}%)`;
for (const r of results) {
  const p = r.cloneInPage;
  const w = r.cloneInWorker;
  row([
    ...label(r),
    p.evaluation.n,
    f(p.evaluation.median, 1),
    f(p.thin.median, 1),
    f(p.thick.median, 1),
    extra(p.evaluation.median, p.thin.median),
    extra(p.evaluation.median, p.thick.median),
    f(w.evaluation.median, 1),
    f(w.thin.median, 1),
    f(w.thick.median, 1),
    f(r.buildInWorker.thin.median, 1),
    f(r.buildInWorker.thick.median, 1),
  ]);
}

console.log("\n2b. postMessage of the reply, worker to page (ms, median of n): transfer = from the request of the page until the page has read the reply\n");
head(["size", "files", "deps", "n", "Evaluation: worker post / page read / transfer", "+ thin: post / read / transfer", "+ thick: post / read / transfer", "extra transfer thin", "extra transfer thick", "longest frame (max) eval/thin/thick"]);
for (const r of results) {
  const of = (form) => {
    const runs = r.echo[form];
    return {
      post: med(runs, (x) => x.worker.postMs),
      read: med(runs, (x) => x.replyReadMs),
      transfer: med(runs, (x) => x.roundTripMs),
      frame: max(runs, (x) => x.longestFrameMs),
    };
  };
  const e = of("evaluation");
  const thin = of("thin");
  const thick = of("thick");
  const cell = (x) => `${f(x.post, 1)} / ${f(x.read, 1)} / ${f(x.transfer, 1)}`;
  row([
    ...label(r),
    r.echo.evaluation.length,
    cell(e),
    cell(thin),
    cell(thick),
    extra(e.transfer, thin.transfer),
    extra(e.transfer, thick.transfer),
    `${f(e.frame, 1)} / ${f(thin.frame, 1)} / ${f(thick.frame, 1)}`,
  ]);
}
console.log("\n2c. Whole round trip with a real evaluation (ms, median of n warm runs)\n");
head(["size", "n", "Evaluation alone", "+ thin", "+ thick", "page read: eval / thin / thick"]);
for (const r of results) {
  row([
    label(r)[0],
    `${r.warm.length}/${r.thin.length}/${r.thick.length}`,
    f(med(r.warm, (x) => x.roundTripMs)),
    f(med(r.thin, (x) => x.roundTripMs)),
    f(med(r.thick, (x) => x.roundTripMs)),
    `${f(med(r.warm, (x) => x.replyReadMs), 1)} / ${f(med(r.thin, (x) => x.replyReadMs), 1)} / ${f(med(r.thick, (x) => x.replyReadMs), 1)}`,
  ]);
}
console.log("\nshared references after the message:");
for (const r of results) console.log(`  ${label(r)[0]}: thin ${JSON.stringify(r.shared.thin)}; thick ${JSON.stringify(r.shared.thick)}`);

console.log("\n3. Aggregation on the page thread (ms per run, median of n samples; each sample is a batch)\n");
head(["size", "files", "deps", "n x batch", "by type ms", "nodes", "edges", "by element ms", "nodes", "edges", "no tests: files", "type nodes/edges", "element nodes/edges", "element ms"]);
for (const r of results) {
  const a = r.aggregate;
  const t = r.aggregateWithoutTests;
  row([
    ...label(r),
    `${a.byType.ms.n} x ${a.byType.batch}/${a.byElement.batch}`,
    f(a.byType.ms.median, 3),
    a.byType.nodes,
    a.byType.edges,
    f(a.byElement.ms.median, 3),
    a.byElement.nodes,
    a.byElement.edges,
    t.files,
    `${t.byType.nodes}/${t.byType.edges}`,
    `${t.byElement.nodes}/${t.byElement.edges}`,
    f(t.byElement.ms.median, 3),
  ]);
}
