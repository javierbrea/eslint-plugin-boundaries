// Runs in the page (main thread). Exposes `window.cost` for the runner.
const now = () => performance.now();
const median = (values) => {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
};
const summary = (values) => ({
  median: median(values),
  min: Math.min(...values),
  max: Math.max(...values),
  n: values.length,
});

// Frame meter: the longest gap between two animation frames since the last reset
const frames = { last: 0, longest: 0, count: 0 };
function tick(time) {
  if (frames.last) frames.longest = Math.max(frames.longest, time - frames.last);
  frames.last = time;
  frames.count++;
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);
const nextFrame = () => new Promise((resolve) => requestAnimationFrame(resolve));
async function resetFrames() {
  await nextFrame();
  frames.longest = 0;
}
async function readFrames() {
  await nextFrame();
  await nextFrame();
  return frames.longest;
}

function spawn() {
  const start = now();
  const worker = new Worker("/worker.js", { type: "module", name: "playground-evaluation" });
  return new Promise((resolve, reject) => {
    worker.onerror = (event) => reject(new Error(`worker error: ${event.message}`));
    worker.onmessage = () => resolve({ worker, loadMs: now() - start });
  });
}

/** Posts a command and waits for the reply and for the timings of the worker */
function request(worker, message) {
  return new Promise((resolve, reject) => {
    const result = {};
    worker.onerror = (event) => reject(new Error(`worker error: ${event.message}`));
    worker.onmessage = (event) => {
      const entered = now();
      const { data } = event;
      const read = now();
      if (data.kind === "reply") {
        result.replyReadMs = read - entered;
        result.roundTripMs = read - result.sendStart;
        result.untilHandlerMs = entered - result.sendStart;
        result.payload = data.payload;
      } else {
        result.worker = data.timings;
        resolve(result);
      }
    };
    result.sendStart = now();
    worker.postMessage(message);
    result.sendMs = now() - result.sendStart;
  });
}

async function measured(worker, message) {
  await resetFrames();
  const result = await request(worker, message);
  result.longestFrameMs = await readFrames();
  return result;
}

/** The plain aggregation of the graph: files into groups, dependencies into edges between the groups of their ends */
function aggregate(evaluation, keyOf) {
  const groups = new Map();
  const groupOfFile = new Map();
  for (const [path, description] of evaluation.files) {
    const key = keyOf(description);
    let group = groups.get(key);
    if (!group) {
      group = { id: key, files: 0, internal: 0 };
      groups.set(key, group);
    }
    group.files += 1;
    groupOfFile.set(path, group);
  }
  const edges = new Map();
  const { dependencies } = evaluation;
  for (let index = 0; index < dependencies.length; index++) {
    const result = dependencies[index];
    const { target } = result.dependency;
    if (target.kind !== "node") continue;
    const from = groupOfFile.get(result.dependency.from);
    const to = groupOfFile.get(target.path);
    if (from === undefined || to === undefined) continue;
    if (from === to) {
      from.internal += 1;
      continue;
    }
    const key = `${from.id}|${to.id}`;
    let edge = edges.get(key);
    if (!edge) {
      edge = { id: key, source: from.id, target: to.id, allowed: 0, disallowed: 0, deps: [] };
      edges.set(key, edge);
    }
    if (result.verdict.status === "disallowed") edge.disallowed += 1;
    else edge.allowed += 1;
    edge.deps.push(index);
  }
  const kept = [...edges.values()];
  for (const edge of kept) edge.mutual = edges.has(`${edge.target}|${edge.source}`);
  return { nodes: [...groups.values()], edges: kept };
}
// The categories that the mockup hides with its tests filter
const TEST_CATEGORIES = ["test", "mock", "pom", "playwright", "playwright-entry"];
const UNCLASSIFIED = "(unclassified)";
const byType = (description) => description.element.types?.join("+") ?? UNCLASSIFIED;
const byElement = (description) => description.element.path ?? UNCLASSIFIED;

function timeAggregate(evaluation, keyOf, warmUp, runs) {
  let graph;
  for (let index = 0; index < warmUp; index++) graph = aggregate(evaluation, keyOf);
  // The clock of the page ticks every 0.1 ms, so a sample is a batch of runs that lasts about 20 ms or more
  const probeStart = now();
  for (let index = 0; index < 5; index++) graph = aggregate(evaluation, keyOf);
  const estimate = (now() - probeStart) / 5;
  const batch = Math.max(1, Math.min(500, Math.ceil(20 / Math.max(estimate, 0.02))));
  const times = [];
  for (let index = 0; index < runs; index++) {
    const start = now();
    for (let inner = 0; inner < batch; inner++) graph = aggregate(evaluation, keyOf);
    times.push((now() - start) / batch);
  }
  const edgesWithDisallowed = graph.edges.filter((edge) => edge.disallowed > 0).length;
  const internal = graph.nodes.reduce((sum, node) => sum + node.internal, 0);
  const crossing = graph.edges.reduce((sum, edge) => sum + edge.allowed + edge.disallowed, 0);
  return {
    ms: summary(times),
    batch,
    nodes: graph.nodes.length,
    edges: graph.edges.length,
    edgesWithDisallowed,
    internalDependencies: internal,
    crossingDependencies: crossing,
  };
}

function timeClone(value, runs) {
  structuredClone(value);
  const times = [];
  for (let index = 0; index < runs; index++) {
    const start = now();
    structuredClone(value);
    times.push(now() - start);
  }
  return summary(times);
}

function checkShared(both) {
  const { evaluation, analysis } = both;
  let files = 0;
  let sharedFiles = 0;
  for (const [path, description] of analysis.files) {
    files++;
    if (evaluation.files.get(path) === description) sharedFiles++;
  }
  let described = 0;
  let sharedDescriptions = 0;
  let sharedDependencies = 0;
  let sharedRefs = 0;
  analysis.dependencies.forEach((result, index) => {
    const other = evaluation.dependencies[index];
    if (result.description !== undefined) {
      described++;
      if (result.description === other.description) sharedDescriptions++;
    }
    if (result.dependency === other.dependency) sharedDependencies++;
    if (result.ref === other.ref) sharedRefs++;
  });
  const policyRefs = new Set(
    analysis.dependencies.map((result) => result.verdict.policy).filter(Boolean)
  );
  return {
    sameMapObject: analysis.files === evaluation.files,
    files,
    sharedFiles,
    dependencies: analysis.dependencies.length,
    described,
    sharedDescriptions,
    sharedDependencies,
    sharedRefs,
    distinctAnalysisPolicyRefs: policyRefs.size,
  };
}

/** A direct test of the structured clone, with no worker and with one */
async function directTest() {
  const shared = { name: "shared", nested: { value: 1 } };
  const viaClone = structuredClone({
    evaluation: { files: new Map([["a", shared]]), list: [shared] },
    analysis: { files: new Map([["a", shared]]), list: [shared] },
  });
  const channel = new MessageChannel();
  const viaPort = await new Promise((resolve) => {
    channel.port2.onmessage = (event) => resolve(event.data);
    channel.port1.postMessage({ one: { files: new Map([["a", shared]]) }, two: [shared] });
  });
  // Two messages do not share: each one is cloned on its own
  const first = structuredClone({ value: shared });
  const second = structuredClone({ value: shared });
  return {
    structuredCloneMapToMap: viaClone.evaluation.files.get("a") === viaClone.analysis.files.get("a"),
    structuredCloneMapToArray: viaClone.evaluation.files.get("a") === viaClone.analysis.list[0],
    cloneIsACopy: viaClone.evaluation.files.get("a") !== shared,
    messagePortMapToArray: viaPort.one.files.get("a") === viaPort.two[0],
    twoMessagesShare: first.value === second.value,
  };
}

function countVerdicts(evaluation) {
  const counts = {};
  for (const { verdict } of evaluation.dependencies) {
    counts[verdict.status] = (counts[verdict.status] ?? 0) + 1;
  }
  return counts;
}

const withChangedTree = (sketch, prefix, index) => ({
  config: sketch.config,
  tree: [...sketch.tree, { path: `${prefix}src/added-by-the-measurement-${index}.ts`, kind: "file" }],
  dependencies: sketch.dependencies,
});

window.cost = {
  directTest,
  async run({ url, prefix, freshWorkers, warmRuns, echoRuns, cloneRuns, aggregateRuns }) {
    const fetchStart = now();
    const sketch = await (await fetch(url)).json();
    const out = {
      files: sketch.tree.length,
      dependencies: sketch.dependencies.length,
      configChars: sketch.config.length,
      fetchAndParseMs: now() - fetchStart,
      idleLongestFrameMs: 0,
      first: [],
      warm: [],
      thin: [],
      thick: [],
      loadMs: [],
    };
    await resetFrames();
    await new Promise((resolve) => setTimeout(resolve, 300));
    out.idleLongestFrameMs = await readFrames();

    let worker;
    let evaluation;
    const strip = ({ payload: _payload, sendStart: _sendStart, ...rest }) => rest;
    for (let index = 0; index < freshWorkers; index++) {
      worker?.terminate();
      const spawned = await spawn();
      worker = spawned.worker;
      out.loadMs.push(spawned.loadMs);
      const first = await measured(worker, { cmd: "evaluate", mode: "evaluation", sketch });
      evaluation = first.payload;
      out.first.push(strip(first));
      for (let run = 0; run < warmRuns; run++) {
        out.warm.push(
          strip(await measured(worker, { cmd: "evaluate", mode: "evaluation", sketch: withChangedTree(sketch, prefix, run) }))
        );
      }
      for (let run = 0; run < warmRuns; run++) {
        out.thin.push(
          strip(await measured(worker, { cmd: "evaluate", mode: "thin", sketch: withChangedTree(sketch, prefix, run) }))
        );
        out.thick.push(
          strip(await measured(worker, { cmd: "evaluate", mode: "thick", sketch: withChangedTree(sketch, prefix, run) }))
        );
      }
    }
    // Where the time goes: the same tree with no dependency, so that only the files are described
    out.filesOnly = [];
    for (let run = 0; run < Math.max(2, warmRuns); run++) {
      out.filesOnly.push(
        strip(await measured(worker, { cmd: "evaluate", mode: "none", sketch: { ...withChangedTree(sketch, prefix, run), dependencies: [] } }))
      );
    }
    out.verdicts = countVerdicts(evaluation);
    out.problems = evaluation.problems.length;
    out.notEvaluated = evaluation.notEvaluated ?? null;
    out.elementTypes = evaluation.elementTypes.length;
    out.policies = evaluation.policies.length;

    // The worker now holds the evaluation of the last sketch: the same reply posted again, in each form, interleaved
    await request(worker, { cmd: "evaluate", mode: "evaluation", sketch });
    const forms = ["evaluation", "thin", "thick"];
    out.echo = Object.fromEntries(forms.map((form) => [form, []]));
    const received = {};
    for (let run = 0; run < echoRuns + 2; run++) {
      for (const form of forms) {
        const result = await measured(worker, { cmd: "echo", form });
        received[form] = result.payload;
        if (run >= 2) out.echo[form].push(strip(result));
      }
    }
    out.shared = { thin: checkShared(received.thin), thick: checkShared(received.thick) };
    out.cloneInWorker = {};
    out.buildInWorker = {};
    for (const form of forms) {
      out.cloneInWorker[form] = summary(
        (await request(worker, { cmd: "clone", form, runs: cloneRuns })).worker.runs
      );
      if (form !== "evaluation") {
        out.buildInWorker[form] = summary(
          (await request(worker, { cmd: "build", form, runs: cloneRuns })).worker.runs
        );
      }
    }
    worker.terminate();
    out.cloneInPage = Object.fromEntries(
      forms.map((form) => [form, timeClone(received[form], cloneRuns)])
    );

    // Aggregation on the page thread, over the evaluation as the page receives it
    const pageEvaluation = received.evaluation;
    out.aggregate = {
      byType: timeAggregate(pageEvaluation, byType, 10, aggregateRuns),
      byElement: timeAggregate(pageEvaluation, byElement, 10, aggregateRuns),
    };
    const isTest = (description) =>
      (description.file.categories ?? []).some((category) =>
        TEST_CATEGORIES.includes(category)
      );
    const withoutTests = {
      files: new Map([...pageEvaluation.files].filter(([, description]) => !isTest(description))),
      dependencies: pageEvaluation.dependencies,
    };
    out.aggregateWithoutTests = {
      files: withoutTests.files.size,
      byType: timeAggregate(withoutTests, byType, 10, aggregateRuns),
      byElement: timeAggregate(withoutTests, byElement, 10, aggregateRuns),
    };
    return out;
  },
};
